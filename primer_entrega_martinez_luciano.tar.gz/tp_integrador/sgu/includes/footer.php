<footer class="is-center bg-light">
    <p>Todos los derechos reservados</p>
</footer>